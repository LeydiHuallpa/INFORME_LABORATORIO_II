# BDII_Informe_Lab_02

1. Abrir una consola de comandos
2. ingresar a una carpeta y ejecutar el comando

   - git clone https://github.com/p-cuadros/BDII_Informe_Lab_02.git

3. Se decargaran los archivos. Luego abrir el TexWorks y editar los archivos

4. Una vez finalizadas las modificaciones para confirmar los cambios ejecutar el comando

   - git commit -m "Escribir un comentario sobre el cambio"

5. Para sicronizar con el repositorio remoto, ejecutar el comando

   - git push origin master

6. Solicitara el usuario y contraseña de Github.

Nota: como alternativa se puede utilizar Github Desktop
